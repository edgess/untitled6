


CREATE   PROCEDURE prc_route_list 
AS
declare @id int
declare @old_id int
declare @route_code varchar(50)
declare @old_route_code varchar(50)
declare @route_name varchar(500)
declare @old_route_name varchar(500)
declare @order_id int
declare @old_order_id int
declare @paragraph varchar(8000)
declare @all_paragraph varchar(8000)


set @old_id = 0

declare cur_route cursor for
  select a.id, a.route_code, a.route_display_name, b.order_id, b.paragraph_title + '<br>' + convert(varchar(8000), b.paragraph_text) as paragraph
    from route_list a, route_schedule b
    where a.id = b.route_id
    and ROUTE_TYPE = '出境游' AND a.IS_DISPLAY = 'Y' AND 
      (ROUTE_CODE IS not NULL and ROUTE_CODE <> '')
    and b.is_display = 'Y'
    order by a.id, b.order_id

delete from route_temp

open cur_route
FETCH NEXT FROM  cur_route  INTO  @id, @route_code, @route_name, @order_id, @paragraph
set @old_id = @id
set @old_route_name = @route_name
set @old_route_code = @route_code
set @old_order_id = @order_id
set @all_paragraph = @paragraph
WHILE   @@fetch_status=0
BEGIN 
FETCH NEXT FROM  cur_route  INTO  @id, @route_code, @route_name, @order_id, @paragraph
if(@id = @old_id)
begin
  set @all_paragraph = @all_paragraph + '<br>' + @paragraph
end
else if(@id <> @old_id)
begin
  insert into route_temp(id, route_code, route_name, order_id, paragraph)
    values(@old_id, @old_route_code, @old_route_name, @old_order_id, @all_paragraph)
  set @all_paragraph = @paragraph
end
set @old_id = @id
set @old_route_name = @route_name
set @old_route_code = @route_code
set @old_order_id = @order_id

END

  insert into route_temp(id, route_code, route_name, order_id, paragraph)
    values(@old_id, @old_route_code, @old_route_name, @old_order_id, @all_paragraph)

CLOSE  cur_route

DEALLOCATE cur_route


go

