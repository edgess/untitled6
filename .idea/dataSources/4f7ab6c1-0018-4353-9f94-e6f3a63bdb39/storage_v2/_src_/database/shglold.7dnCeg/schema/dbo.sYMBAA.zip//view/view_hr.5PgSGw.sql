CREATE VIEW dbo.View_HR
AS
SELECT   dbo.Operator_Info.name, dbo.Operator_Info.sex, dbo.Operator_Info.shengfzh, dbo.agent.Dept_name, 
                dbo.Operator_Info.status, dbo.Operator_Info.hunyzk, dbo.Operator_Info.jingsrq
FROM      dbo.agent INNER JOIN
                dbo.Operator_Info ON dbo.agent.ID = dbo.Operator_Info.agent_id
WHERE   (dbo.agent.Agent_type = '公司部门')
go

