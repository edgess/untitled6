
CREATE  view v_crm_mobile as
SELECT MOBILE,NAME,birthday,case sex when '男性' then '男' when '女性' then '女' end sex,'member_doc' source
FROM MEMBER_DOC
WHERE (ISNULL(MOBILE, '') <> '') 
union
select mobile,name,birthday,sex,'trm_member' source
from trm_member 
where isnull(member_code,'')<>'FMFFP' and (isnull(mobile,'')<>'' )

go

