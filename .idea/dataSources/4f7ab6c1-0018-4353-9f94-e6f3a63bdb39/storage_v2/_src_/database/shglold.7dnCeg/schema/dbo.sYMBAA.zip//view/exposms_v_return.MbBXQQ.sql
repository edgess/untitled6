CREATE VIEW dbo.ExpoSMS_V_Return
AS
SELECT dbo.ExpoSMS_Mobile.mobile_num, dbo.ExpoSMS_Mobile.name, 
      SH962008.dbo.WEB_SMS.Times, SH962008.dbo.WEB_SMS.Msg
FROM SH962008.dbo.WEB_SMS LEFT OUTER JOIN
      dbo.ExpoSMS_Mobile ON 
      SH962008.dbo.WEB_SMS.Mp = dbo.ExpoSMS_Mobile.mobile_num AND 
      dbo.ExpoSMS_Mobile.is_valid = 'Y'
WHERE (SH962008.dbo.WEB_SMS.Msg LIKE 'ex%')
go

exec sp_addextendedproperty 'MS_Description', '手机号', 'SCHEMA', 'dbo', 'VIEW', 'ExpoSMS_V_Return', 'COLUMN', 'mobile_num'
go

exec sp_addextendedproperty 'MS_Description', '姓名', 'SCHEMA', 'dbo', 'VIEW', 'ExpoSMS_V_Return', 'COLUMN', 'name'
go

