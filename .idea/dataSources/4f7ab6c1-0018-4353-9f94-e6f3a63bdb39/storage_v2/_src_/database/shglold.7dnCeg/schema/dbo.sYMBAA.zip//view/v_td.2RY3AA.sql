


CREATE    view v_td as
SELECT a.xl, a.cfrq, a.lkrq, a.qcts, a.sprs, a.jhrs, a.bj1,a.memo, b.*
FROM hwy2002_shgl.dbo.hw_td a, hwy2002_shgl.dbo.hw_tdxc b
where a.th = b.th
and a.cfrq > getdate()


go

