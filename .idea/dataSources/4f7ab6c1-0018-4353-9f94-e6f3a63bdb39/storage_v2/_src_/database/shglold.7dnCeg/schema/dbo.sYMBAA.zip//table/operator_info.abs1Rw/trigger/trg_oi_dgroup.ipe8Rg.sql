CREATE TRIGGER [trg_oi_dgroup] ON dbo.Operator_Info 
FOR DELETE 
AS
  delete Group_Oper where op_id =(select id from Deleted )
go

