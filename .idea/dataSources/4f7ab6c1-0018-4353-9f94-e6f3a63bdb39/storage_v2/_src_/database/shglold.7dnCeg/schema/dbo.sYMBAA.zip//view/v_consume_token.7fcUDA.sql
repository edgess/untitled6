create view v_consume_token as
select a.record_id consume_record_id,a.mem_id,a.consume_kind,a.consume_sub_kind,
a.consume_item,a.consume_sub_item,a.consume_money,a.consume_date,b.token_used,c.token_code ,c.record_id token_record_id
from trm_consume_record a,trm_consume_token b,trm_token c
where a.record_id=b.consume_record_id and b.token_record_id=c.record_id
go

