create view v_birthday_month as select * from operator_info where isemployee='Y'
and month(chusrq)=month(getdate())
go

