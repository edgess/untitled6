-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[PROCE_PAGECHANGE] 
	(
		@TableName varchar(50),            --表名
		@ReFieldsStr varchar(max) = '*',   --字段名(全部字段为*)
		@OrderString varchar(max),         --排序字段(必须!支持多字段不用加order by)
		@WhereString varchar(max) =N'',  --条件语句(不用加where)
		@PageSize int,                     --每页多少条记录
		@PageIndex int = 1,               --指定当前为第几页
		@TotalRecord int output            --返回总记录数
	)	
AS
BEGIN
	--处理开始点和结束点
    Declare @StartRecord int;
    Declare @EndRecord int; 
    Declare @TotalCountSql nvarchar(max); 
    Declare @SqlString nvarchar(max);    
    set @StartRecord = (@PageIndex-1)*@PageSize + 1
    set @EndRecord = @StartRecord + @PageSize - 1 
    SET @TotalCountSql= N'select @TotalRecord = count(*) from ' + @TableName;--总记录数语句
    SET @SqlString = N'select row_number() over (order by '+ @OrderString +') as rowId,'+@ReFieldsStr+' from '+ @TableName;--查询语句
    
    IF (@WhereString! = '' or @WhereString!=null)
        BEGIN
            SET @TotalCountSql=@TotalCountSql + '  where '+ @WhereString;
            SET @SqlString =@SqlString+ '  where '+ @WhereString;            
        END
    --第一次执行得到
    --IF(@TotalRecord is null)
    --   BEGIN
           EXEC sp_executesql @totalCountSql,N'@TotalRecord int out',@TotalRecord output;--返回总记录数
    --  END
    ----执行主语句
    
    --set @SqlString ='select * from (' + @SqlString + ') as t where rowId between ' + ltrim(str(@StartRecord)) + ' and ' +  ltrim(str(@EndRecord));
    set @SqlString ='select '+ @ReFieldsStr +' from (' + @SqlString + ') as t where rowId between ' + ltrim(str(@StartRecord)) + ' and ' +  ltrim(str(@EndRecord));
    
    Exec(@SqlString)  
	
END
go

