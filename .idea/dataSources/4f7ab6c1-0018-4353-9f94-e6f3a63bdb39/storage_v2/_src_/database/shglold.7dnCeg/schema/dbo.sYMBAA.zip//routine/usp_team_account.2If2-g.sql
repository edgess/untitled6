

CREATE   procedure usp_team_account (@team_code varchar(30) )
as
----------------------
declare @customers varchar(1000)
declare @customer varchar(10)
declare @singup_id varchar(40)
declare @personnum int
-----------------------
create table #teamaccount 
(
id int IDENTITY(1,1),
游客姓名 varchar(1000),
销售员 varchar(20),
应收款 money,
结算金额 money, --added at 2004-11-3
现收款 money,
欠款 money,
备注 varchar(1000),
报名号 varchar(40),
人数 int
)
insert into #teamaccount 
select '' 游客姓名,--customer_info.chinese_name
operator_info.name 销售员,
coalesce((select sum(receivable_account.amount) from receivable_account where receivable_account.signup_id=sign_up.signup_id),0) 应收款,
coalesce((select sum(receivable_account.Cost_sum) from receivable_account where receivable_account.signup_id=sign_up.signup_id),0) 结算金额,
coalesce((select sum(paid_record.paid_amount) from paid_record where paid_record.signup_id=sign_up.signup_id),0) 现收款,
coalesce((select sum(receivable_account.amount) from receivable_account where receivable_account.signup_id=sign_up.signup_id),0) -coalesce((select sum(paid_record.paid_amount) from paid_record where paid_record.signup_id=sign_up.signup_id),0)  欠款,
sign_up.remark 备注,
sign_up.signup_id 报名号, 
0 人数
from sign_up, operator_info --,team_member --, customer_info 
where sign_up.team_id=@team_code --'SH10C-400500豪华'
and operator_info.id =  sign_up.salesman_id
order by 报名号
--select * from #teamaccount

------------------------
----------------------
declare cr_signup cursor for
select signup_id from sign_up where team_id = @team_code --'SH10C-400500豪华'
----------------------
open cr_signup
FETCH NEXT FROM cr_signup into @singup_id

WHILE @@FETCH_STATUS = 0
BEGIN
	declare cr_customers cursor  for
	select chinese_name from team_member , customer_info 
	where team_member.customer_id= customer_info.customer_id and 
	signup_id= @singup_id --'A2004091400003'
	order by team_member.member_order

	set @customers=''
	set @personnum = 0
	open cr_customers
	FETCH NEXT FROM cr_customers into @customer    
	WHILE @@FETCH_STATUS = 0
	BEGIN	    
		if (@customers='')
		begin
			set @customers = @customer
		end
		else
		begin
			set @customers = @customers + '<br>' +@customer
		end 
		set @personnum = @personnum+1
		FETCH NEXT FROM cr_customers into @customer
	END  
	CLOSE cr_customers
	DEALLOCATE cr_customers
	
	update 	#teamaccount set 游客姓名=@customers,人数=@personnum where 报名号=@singup_id
--	DEALLOCATE cr_signup

	FETCH NEXT FROM cr_signup into @singup_id
END



CLOSE cr_signup
DEALLOCATE cr_signup

select * from #teamaccount


go

