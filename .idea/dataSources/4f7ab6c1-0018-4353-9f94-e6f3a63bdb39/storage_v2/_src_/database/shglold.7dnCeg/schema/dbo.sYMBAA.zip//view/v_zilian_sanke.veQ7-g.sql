/*and a.nian=2005
order by nian,bum,laibzl,tl,xiangm
*/
CREATE VIEW dbo.v_zilian_sanke
AS
SELECT a.nian, a.bum AS bumbh, b.name AS bum, a.laibzl AS lbbh, c.mc AS laibzl, 
      a.tl AS tlbh, d.mc AS tl, a.xiangm AS xmbh, e.mc AS xiangm, a.wl1 AS yue1, 
      a.wl2 AS yue2, a.wl3 AS yue3, a.wl4 AS yue4, a.wl5 AS yue5, a.wl6 AS yue6, 
      a.wl7 AS yue7, a.wl8 AS yue8, a.wl9 AS yue9, a.wl10 AS yue10, a.wl11 AS yue11, 
      a.wl12 AS yue12, 
      a.wl1 + a.wl2 + a.wl3 + a.wl4 + a.wl5 + a.wl6 + a.wl7 + a.wl8 + a.wl9 + a.wl10 + a.wl11 +
       a.wl12 AS yearsum
FROM dbo.shgl_inbound a INNER JOIN
      dbo.d_dep b ON a.bum = b.dm INNER JOIN
      dbo.d_lbzl c ON a.laibzl = c.dm INNER JOIN
      dbo.shgl_inbound_tl d ON a.tl = d.dm INNER JOIN
      dbo.shgl_inbound_xiangm e ON a.xiangm = e.dm
go

