
CREATE  view v_person_station as

select 
a.id,a.renshi_id,a.bianh,a.gongh,a.name,a.shengfzh,a.agent_id,a.status,a.station_name station_id,
b.station_name,b.dept_belong,b.superior,b.junior,b.direction,b.description,b.qualification,
c.agent_name,
substring(c.order_id,1,2) level1,
substring(c.order_id,3,2) level2,substring(c.order_id,5,2) level3

from operator_info a,saltrip_station b,agent c 
where a.isemployee='Y' and a.station_name=b.id and a.agent_id=c.id


go

