CREATE TRIGGER [trg_oi_igroupid] ON dbo.Operator_Info 
after INSERT
AS
insert into  Group_Oper(op_id,group_id)  select id,10 from inserted
go

