
/*ALTER  view v_outbound_td as
select year(yqrq1) nian,month(yqrq1) yue,rtrim(th) th ,count(*) rs
from [192.168.100.2].hwy2002_shgl.dbo.hw_dztly
where isnull(th,'')<>''
group by year(yqrq1),month(yqrq1),rtrim(th)
*/

CREATE view v_outbound_per_month as
select nian,yue,count(*) tds,sum(rs) zrs
from v_outbound_td
group by nian,yue

go

