











CREATE  view v_tax_sat0802 as 
SELECT '1~~' + 
  shenfzh 
 + '~~010000~~1~~20080201~~20080229~~29~~'
 + CONVERT(varchar(20), jine)
 + '~~'+CONVERT(varchar(20), isnull(kouj,0))+'~~0~~0' AS Expr1
FROM saltrip_gz
where nian='08' and yue='02' and py=0 and left(bm,5)<>'01006'

union

SELECT '1~~' + 
  shenfzh 
 + '~~040000~~1~~20080201~~20080229~~29~~'
 + CONVERT(varchar(20), jine)
 + '~~'+CONVERT(varchar(20), isnull(kouj,0))+'~~0~~0' AS Expr1
FROM saltrip_gz
where nian='08' and yue='02' and py>0 and left(bm,5)<>'01006'


go

