CREATE TRIGGER [trg_oi_ustatus] ON dbo.Operator_Info 
FOR UPDATE
AS
if update(status)
delete Group_Oper where op_id=
(select id from inserted  where status='离岗' or status='退休' or status='离职')
go

