
CREATE  view t_bum (id,bumbh,bum) as
select id,substring(order_id,1,2),agent_name 
from agent where agent_type in ('公司部门','直销网点') and status='Y'
and len(order_id)=2

go

