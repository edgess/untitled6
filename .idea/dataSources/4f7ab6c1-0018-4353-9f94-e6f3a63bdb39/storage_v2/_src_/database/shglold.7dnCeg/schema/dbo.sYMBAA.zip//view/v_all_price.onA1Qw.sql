
create   view v_all_price as
select *
from WLVACATION.dbo.v_all_price


go

