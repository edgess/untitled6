create view v_b2c_firstdeal as
select stringid,signup_id,min(check_time) first_deal_time,count(*) deal_times
FROM B2C_SIGNUP_history
group by stringid,signup_id


go

