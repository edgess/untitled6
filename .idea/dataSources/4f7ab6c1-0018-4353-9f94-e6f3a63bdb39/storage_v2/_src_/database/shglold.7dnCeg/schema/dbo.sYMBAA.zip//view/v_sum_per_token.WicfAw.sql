
--每次充值的已使用总额

CREATE   view v_sum_per_token as
select token_record_id,sum(token_used) token_used
from trm_consume_token
group by token_record_id


go

