

CREATE   VIEW dbo.v_all_line
AS
SELECT 线路名, 地区, MIN(参考价) AS 参考价, COUNT(*) AS 团队数, max(page) as page, min(page_order) as page_order
FROM (SELECT line_info.Line_name AS 线路名, line_info.area AS 地区,
                  (SELECT price_single
                 FROM inlandtravel.dbo.quote_info quote_info
                 WHERE quote_info.line_id = line_info.id AND price_type = '标准价格') 
              AS 参考价, case when len(line_code) > 3 then left(line_code, 3) else 'ALL' end as page, case when len(line_code) > 3 then substring(line_code, 4, len(line_code) - 3) else '99999' end as page_order
        FROM inlandtravel.dbo.line_info line_info
        WHERE is_templet = 0 AND is_publish = 1 AND is_publish_b2b = 1 AND 
              date_end > getdate()
        UNION ALL
        SELECT g_route_query.route_name AS 线路名, g_route_query.destination AS 地区, 
              g_route_query.adult_price AS 参考价, g_system_code.code_information as page,
              g_route_query.release_number as page_order
        FROM wlvacation.dbo.g_route_query g_route_query inner join wlvacation.dbo.g_system_code g_system_code on g_route_query.release_position = g_system_code.id
        WHERE leave_date > getdate() and isrelease = '是') x
GROUP BY 线路名, 地区


go

