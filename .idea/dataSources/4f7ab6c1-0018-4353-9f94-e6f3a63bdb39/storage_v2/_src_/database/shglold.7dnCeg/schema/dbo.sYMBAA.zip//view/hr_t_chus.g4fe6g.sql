CREATE VIEW dbo.hr_t_chus
AS
SELECT   ID, SUBSTRING(order_id, 1, 2) AS bumbh, SUBSTRING(order_id, 3, 2) AS chusbh, agent_name AS chus
FROM      dbo.hr_agent
WHERE   (Agent_type IN ('公司部门', '直销网点')) AND (LEN(order_id) = 4)
go

