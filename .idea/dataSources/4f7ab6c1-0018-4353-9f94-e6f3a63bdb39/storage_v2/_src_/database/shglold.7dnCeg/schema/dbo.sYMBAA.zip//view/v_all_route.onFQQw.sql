CREATE VIEW dbo.v_all_route
AS
SELECT line_info.id AS ID, line_info.Line_name AS 团队名, line_info.Team_code AS 团号, 
      line_info.person_num AS 计划人数, iformal_seated AS 报名人数, 
      ipreserve_seated AS 预留人数, iLeft AS 剩余名额, CONVERT(char(10), 
      line_info.date_go, 102) AS 出团日期, CONVERT(char(10), date_end, 102) 
      AS 截止报名日期,
          (SELECT price_single
         FROM inlandtravel.dbo.quote_info quote_info
         WHERE quote_info.line_id = line_info.id AND price_type = '标准价格') AS 成人价,
          (SELECT price_single
         FROM inlandtravel.dbo.quote_info quote_info
         WHERE quote_info.line_id = line_info.id AND price_type = '儿童价格') AS 儿童价, 
      line_info.Team_code AS 订单号, line_info.id AS iOpe_line_id, '上航国旅' AS 来源
FROM inlandtravel.dbo.line_info line_info INNER JOIN
      inlandtravel.dbo.v_b2b_person_num v_b2b_person_num ON 
      line_info.id = v_b2b_person_num.id
WHERE is_templet = 0 AND is_publish = 1 AND is_publish_b2b = 1 AND 
      date_end > getdate()
UNION
SELECT g_route_query.id AS ID, g_route_query.route_name AS 团队名, 
      g_route_query.group_number AS 团号, g_route_query.plan_number AS 计划人数, 
      g_route_query.enter_for AS 报名人数, g_route_query.reserve AS 预留人数, 
      g_route_query.remain AS 剩余名额, CONVERT(char(10), g_route_query.leave_date, 
      102) AS 出团日期, CONVERT(char(10), g_route_query.leave_date, 102) 
      AS 截止报名日期, g_route_query.adult_price AS 成人价, 
      g_route_query.children_price AS 儿童价, g_route_query.order_number AS 订单号, 
      g_route_query.id AS iOpe_line_id, '上航假期' AS 来源
FROM wlvacation.dbo.g_route_query g_route_query
WHERE leave_date > getdate()
go

