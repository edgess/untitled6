--每位会员消费的总次数，总金额，支出总预付充值的统计
CREATE  view v_sum_member_consume as
select mem_id,count(*) times,sum(consume_money) total_consume,sum(token_used) total_token from trm_consume_record
group by mem_id

go

