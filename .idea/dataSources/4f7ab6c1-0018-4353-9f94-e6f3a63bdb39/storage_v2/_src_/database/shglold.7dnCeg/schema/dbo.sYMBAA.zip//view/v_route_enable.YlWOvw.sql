
create  view v_route_enable as
select *
from WLVACATION.dbo.v_route_enable


go

