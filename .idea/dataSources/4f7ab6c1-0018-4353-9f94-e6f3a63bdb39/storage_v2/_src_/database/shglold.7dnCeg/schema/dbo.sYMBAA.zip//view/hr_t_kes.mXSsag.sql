CREATE VIEW dbo.hr_t_kes
AS
SELECT   ID, SUBSTRING(order_id, 1, 2) AS bumbh, SUBSTRING(order_id, 3, 2) AS chusbh, SUBSTRING(order_id, 5, 2) AS kesbh, 
                agent_name AS kes
FROM      dbo.hr_agent
WHERE   (Agent_type IN ('公司部门', '直销网点')) AND (LEN(order_id) = 6)
go

