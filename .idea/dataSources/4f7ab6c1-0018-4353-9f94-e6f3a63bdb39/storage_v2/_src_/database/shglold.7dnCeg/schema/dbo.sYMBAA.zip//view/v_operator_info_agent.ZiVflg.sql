CREATE VIEW dbo.v_operator_info_agent
AS
SELECT dbo.Operator_Info.id, dbo.Operator_Info.name, dbo.Operator_Info.sex, 
      dbo.Operator_Info.login_name, dbo.Operator_Info.email, dbo.Operator_Info.mob, 
      dbo.Operator_Info.Fax_ID, dbo.agent.Dept_name, dbo.agent.order_id, 
      ISNULL(dbo.Operator_Info.status, '') AS status
FROM dbo.Operator_Info INNER JOIN
      dbo.agent ON dbo.Operator_Info.agent_id = dbo.agent.ID
WHERE (dbo.agent.Agent_type = '公司部门') AND (dbo.Operator_Info.status <> '离职') AND 
      (dbo.Operator_Info.status <> '退休') AND (dbo.Operator_Info.status <> '死亡') AND 
      (dbo.agent.STATUS = 'Y') AND (dbo.Operator_Info.disabled = 0)
go

