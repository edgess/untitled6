--单次消费用去的预付值（或旅游券）
CREATE  view v_sum_per_consume as
select consume_record_id,sum(token_used) token_used
from trm_consume_token
group by consume_record_id


go

