create view t_chus (id,bumbh,chusbh,chus) as
select id,substring(order_id,1,2),substring(order_id,3,2),agent_name from agent where agent_type in ('公司部门','直销网点') 
and len(order_id)=4
go

