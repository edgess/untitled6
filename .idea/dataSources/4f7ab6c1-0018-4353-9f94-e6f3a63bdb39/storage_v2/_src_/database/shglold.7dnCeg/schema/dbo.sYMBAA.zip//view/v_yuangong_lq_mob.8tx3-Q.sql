create  view v_yuangong_lq_mob as SELECT mob,name,chusrq,sex,agent_name
FROM Operator_Info
WHERE (ISNULL(MOB, '') <> '') and status<>'离职' and status<>'退休'
and agent_id in (select id from agent where order_id like '09%')
go

