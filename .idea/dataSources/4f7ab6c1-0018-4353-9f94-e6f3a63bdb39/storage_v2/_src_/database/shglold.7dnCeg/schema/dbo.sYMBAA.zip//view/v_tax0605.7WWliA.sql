



/*
证件类型~~证件号~~所得项目~~含税标志~~所属期起~~所属期止~~天数~~收入额~~扣除额~~税额~~减免税额
*/




create       view v_tax0605 as 
SELECT '1~~' + 
  shenfzh 
 + '~~010000~~1~~20060501~~20060531~~31~~'
 + CONVERT(varchar(20), jine)
 + '~~'+CONVERT(varchar(20), isnull(kouj,0))+'~~0~~0' AS Expr1
FROM saltrip_gz
where nian='06' and yue='05' and py=0

union

SELECT '1~~' + 
  shenfzh 
 + '~~040000~~1~~20060501~~20060531~~31~~'
 + CONVERT(varchar(20), jine)
 + '~~'+CONVERT(varchar(20), isnull(kouj,0))+'~~0~~0' AS Expr1
FROM saltrip_gz
where nian='06' and yue='05' and py>0


go

