create view v_saltrip_hr as
select string,
charindex('~~',string)+2 startspot,
charindex('~~1',string)-charindex('~~',string)-2 endspot,
substring(string,charindex('~~',string)+2,charindex('~~1',string)-charindex('~~',string)-2) name
from saltrip_hr
go

