CREATE VIEW dbo.ExpoSMS_V_Operator
AS
SELECT dbo.Operator_Info.id, dbo.Operator_Info.name, dbo.Operator_Info.login_name, 
      dbo.Operator_Info.pwd
FROM dbo.Group_Oper INNER JOIN
      dbo.Operator_Info ON dbo.Group_Oper.op_id = dbo.Operator_Info.id
WHERE (dbo.Group_Oper.group_id = 167)
go

exec sp_addextendedproperty 'MS_Description', 'id', 'SCHEMA', 'dbo', 'VIEW', 'ExpoSMS_V_Operator', 'COLUMN', 'id'
go

exec sp_addextendedproperty 'MS_Description', '真实姓名', 'SCHEMA', 'dbo', 'VIEW', 'ExpoSMS_V_Operator', 'COLUMN', 'name'
go

exec sp_addextendedproperty 'MS_Description', '登录名', 'SCHEMA', 'dbo', 'VIEW', 'ExpoSMS_V_Operator', 'COLUMN',
                            'login_name'
go

exec sp_addextendedproperty 'MS_Description', '密码', 'SCHEMA', 'dbo', 'VIEW', 'ExpoSMS_V_Operator', 'COLUMN', 'pwd'
go

