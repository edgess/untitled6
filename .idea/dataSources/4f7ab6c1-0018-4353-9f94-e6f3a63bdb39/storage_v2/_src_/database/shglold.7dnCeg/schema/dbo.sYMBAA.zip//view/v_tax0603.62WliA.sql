







create       view v_tax0603 as 
SELECT '1~~' + 

  shenfzh 

 + '~~010000~~1~~20060301~~20060331~~31~~'
 + CONVERT(varchar(20), jine)
 + '~~'+CONVERT(varchar(20), isnull(kouj,0))+'~~0~~0' AS Expr1
FROM saltrip_gz
where nian='06' and yue='03'


go

