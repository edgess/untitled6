
create   view v_team_enable as
select *
from WLVACATION.dbo.v_team_enable


go

