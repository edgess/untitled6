CREATE VIEW dbo.v_holiday_td
AS
SELECT a.xl, a.cfrq, a.lkrq, a.qcts, a.sprs, a.jhrs, a.bj1, a.memo, b.*
FROM hwy2002_shgl.dbo.hw_td a INNER JOIN
      hwy2002_shgl.dbo.hw_tdxc b ON a.th = b.th
WHERE (a.cfrq >= '2007-09-28') AND (a.cfrq <= '2007-10-05')
go

