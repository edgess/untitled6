



CREATE  view [dbo].[v_tax_sat1602months] as 
SELECT '1~~' +  shenfzh + '~~010001~~1~~20150101~~20151231~~0~~0~~0~~0~~0' AS Expr1
FROM saltrip_gz
where nian='15' and yue='12' and py=0 and left(bm,5)<>'01006'

union

SELECT '1~~' +  shenfzh + '~~010001~~1~~20150101~~20151231~~0~~0~~0~~0~~0' AS Expr1
FROM saltrip_gz
where nian='15' and yue='12' and py>0 and left(bm,5)<>'01006'


go

