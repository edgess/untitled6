CREATE VIEW dbo.v_ModuleInfo
AS
SELECT TOP 100 PERCENT Mod.*, ISNULL(UpMod.menu_name, '') AS Up_Menu
FROM dbo.Module_Info Mod LEFT OUTER JOIN
      dbo.Module_Info UpMod ON Mod.upid = UpMod.id
ORDER BY ISNULL(UpMod.menu_name, ''), Mod.order_num
go

