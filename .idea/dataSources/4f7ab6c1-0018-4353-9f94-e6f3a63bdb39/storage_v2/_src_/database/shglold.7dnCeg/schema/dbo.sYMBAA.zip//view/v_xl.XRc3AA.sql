


CREATE    view v_xl as
SELECT a.*, b.shgl_id, c.order_id agent_order_id, c.agent_name agent_name
FROM hwy2002_shgl.dbo.hw_xl a, hwy2002_shgl.dbo.d_dep b, agent c
where a.bm = b.dm
  and b.shgl_id = c.id


go

