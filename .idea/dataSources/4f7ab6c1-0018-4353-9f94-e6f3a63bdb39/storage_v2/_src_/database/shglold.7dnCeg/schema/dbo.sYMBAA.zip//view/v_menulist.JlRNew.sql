CREATE VIEW dbo.v_MenuList
AS
SELECT TOP 100 PERCENT dbo.Group_Oper.op_id AS op_id, 
      dbo.GrantFunc.group_id AS group_id, dbo.Module_Info.*
FROM dbo.Group_Oper INNER JOIN
      dbo.Group_Info ON dbo.Group_Oper.group_id = dbo.Group_Info.id INNER JOIN
      dbo.GrantFunc ON dbo.Group_Info.id = dbo.GrantFunc.group_id INNER JOIN
      dbo.Module_Info ON dbo.GrantFunc.module_id = dbo.Module_Info.id
WHERE (dbo.Module_Info.menu_lv = 2)
ORDER BY dbo.Module_Info.order_num
go

