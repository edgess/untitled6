CREATE VIEW dbo.CC_V_Right3
AS
SELECT DISTINCT id, name, agentid, Dept_name, tel
FROM dbo.CC_V_Right
WHERE (Group_Info_name = 'vms导游') OR
      (Group_Info_name = 'IB导游')
go

