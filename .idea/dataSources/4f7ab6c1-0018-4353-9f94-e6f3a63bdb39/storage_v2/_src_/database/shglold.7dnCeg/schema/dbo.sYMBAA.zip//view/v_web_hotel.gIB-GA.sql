CREATE VIEW dbo.v_web_hotel
AS
SELECT srr_demo.dbo.srr_web_hotel.*
FROM srr_demo.dbo.srr_web_hotel
go

