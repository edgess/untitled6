









CREATE          procedure usp_cj (@para_year varchar(4),@para_month varchar(2) )
AS 
declare @curr_year int
declare @curr_month int
declare @qcts int
declare @err_code varchar(1000)
declare @ywy_code varchar(20)/*op代码*/
declare @bm_code varchar(20)/*部门代码*/
declare @err_table varchar(10)
declare @bm varchar(20)
declare @username varchar(20)
declare @sysname varchar(50) set @sysname='出境游计调系统'
declare @proce varchar(20) set @proce='前往国月统计'

delete from shgl_outbound_log where nian=@para_year and yue=@para_month and sysname=@sysname and proce=@proce

set @curr_year=@para_year
set @curr_month=@para_month

declare @count_line int
--对应hw_dztly的变量说明
declare @th varchar(40)/*团号*/
declare @tdrs int/*团队人数*/

--对应hw_td的变量说明
declare @lyxl varchar(40)/*线路号*/

--对应hw_xl的变量说明
declare @qwgj varchar(400)/*前往国家*/

--最后统计值

declare cursor_td cursor for
select rtrim(th) th,count(*)/*人数*/ rs
from /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_dztly 
where year(yqrq1)=@curr_year and month(yqrq1)=@curr_month and th is not null and th<>''
group by th

declare @sql nvarchar(1000)
declare @cond varchar(1000)

update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj2=qwgj where isnull(qwgj2,'')=''  
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'、',','), qwgj2=replace(qwgj2,'、',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'，',','), qwgj2=replace(qwgj2,'，',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'。',','), qwgj2=replace(qwgj2,'。',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'‘',','), qwgj2=replace(qwgj2,'‘',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'／',','), qwgj2=replace(qwgj2,'／',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'＼',','), qwgj2=replace(qwgj2,'＼',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'＇',','), qwgj2=replace(qwgj2,'＇',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'；',','), qwgj2=replace(qwgj2,'；',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'　',','), qwgj2=replace(qwgj2,'　',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,' ',','), qwgj2=replace(qwgj2,' ',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'\',','), qwgj2=replace(qwgj2,'\',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'/',','), qwgj2=replace(qwgj2,'/',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,'.',','), qwgj2=replace(qwgj2,'.',',') 
update /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl
set qwgj=replace(qwgj,';',','), qwgj2=replace(qwgj2,';',',')


set @sql = N'update shgl_outbound set '+
           'td'+cast(@curr_month as varchar(2))+' = 0,'+
           'sz'+cast(@curr_month as varchar(2))+' = 0,'+
           'rts'+cast(@curr_month as varchar(2))+' = 0,'+
           'qw'+cast(@curr_month as varchar(2))+' = 0 where nian='+cast(@curr_year as varchar(4))
exec sp_executesql  @sql

--循环处理hw_dztly数据

declare @foundrows int
declare @cut_point int
declare @gj varchar(50)
declare @first char(1)--首站国标志

open cursor_td
WHILE 1=1
BEGIN
   fetch next from cursor_td into @th,@tdrs
   if @@FETCH_STATUS <> 0 break
   set @err_code='NONE'
   set @bm_code=''
   set @ywy_code=''
   set @bm=''
   set @username=''
   set @err_table=''
   select @foundrows=count(*) from /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_td where th=@th
   --hw_dztly中的团号在hw_td中不存在
   if @foundrows=0 set @err_code='游客名单中的团号'''+@th+'''在团队计划中不存在' 
   --hw_dztly中的团号在hw_td中重复
   if @foundrows>1 set @err_code='游客名单中的团号'''+@th+'''在团队计划中存在重复现象' 
   if @foundrows=1 
      select @lyxl=rtrim(xl),@bm_code=rtrim(bm),@ywy_code=rtrim(ywy),@err_table='TD' from /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_td where th=@th
      begin
         select @foundrows=count(*) from /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl where dm=@lyxl
         --hw_dztly中的团号在hw_td中不存在
         if @foundrows=0 set @err_code='团号'''+@th+'''对应的线路代码'''+@lyxl+'''在线路计划中不存在' 
         --hw_dztly中的团号在hw_td中重复
         if @foundrows>1 
            set @err_code='团号'''+@th+'''对应的线路代码'''+@lyxl+'''在线路计划中存在重复现象' 
         if @foundrows=1 
            begin
               select @qcts=qcts,@qwgj=isnull(rtrim(qwgj2),''),@bm_code=rtrim(bm),@ywy_code=rtrim(ywy),@err_table='XL' from /*[192.168.10.2].*/[hwy2002_shgl].[dbo].hw_xl where dm=@lyxl
               if len(@qwgj)<2 set @err_code='线路'''+@lyxl+'''的前往国家不正确' 
               else 
                  begin
                     if  @qcts<1 set @err_code='线路'''+@lyxl+'''的全程天数不正确' 
                     else
                        begin
                           set @qwgj=@qwgj+',' set @qwgj=replace(@qwgj,'、',',') set @qwgj=replace(@qwgj,'，',',') set @qwgj=replace(@qwgj,'。',',') set @qwgj=replace(@qwgj,'‘',',') set @qwgj=replace(@qwgj,'／',',') set @qwgj=replace(@qwgj,'＼',',') set @qwgj=replace(@qwgj,'＇',',') set @qwgj=replace(@qwgj,'；',',') set @qwgj=replace(@qwgj,'　',',') set @qwgj=replace(@qwgj,' ',',') set @qwgj=replace(@qwgj,'\',',') set @qwgj=replace(@qwgj,'/',',') set @qwgj=replace(@qwgj,'.',',') set @qwgj=replace(@qwgj,';',',')
                           set @cut_point=1
                           set @first='Y'
                           while @cut_point<len(@qwgj)
                           begin
                              set @gj=substring(@qwgj,1,charindex(',',@qwgj)-1)
                              select @foundrows=count(*) from /*[192.168.10.2].*/[hwy2002_shgl].[dbo].d_gj where name=@gj
                              --hw_xl中的前往国家在d_gj中不存在
                              if @foundrows=0 set @err_code='线路'''+@lyxl+'''的前往国家'''+@gj+'''在国家资料中不存在' 
                              --hw_xl中的前往国家在d_gj中重复
                              if @foundrows>1 set @err_code='线路'''+@lyxl+'''的前往国家'''+@gj+'''在国家资料中重复' 
                              if @foundrows=1 
                                 begin
                                    select @foundrows=count(*) from shgl_outbound where gj=@gj and nian=@curr_year
                                    if @foundrows=0 insert into shgl_outbound (nian,gj) values (@curr_year,@gj)
                                    set @sql = 'update shgl_outbound set qw'+
                                         cast(@curr_month as varchar(2))+' = qw'+
                                         cast(@curr_month as varchar(2))+'+'+cast(@tdrs as char)
                                    if @first='Y'
                                    begin
                                    set @sql =@sql+ ',sz'+cast(@curr_month as varchar(2))+
                                                 ' = sz'+cast(@curr_month as varchar(2))+ 
                                                 '+'+cast(@tdrs as char)
                                    set @sql =@sql+',rts'+cast(@curr_month as varchar(2))+
                                                 ' = rts'+cast(@curr_month as varchar(2))+ 
                                                 '+'+cast(@tdrs*@qcts as char)
                                    set @sql =@sql+',td'+cast(@curr_month as varchar(2))+
                                                 ' = td'+cast(@curr_month as varchar(2))+ 
                                                 '+1'
                                    end
                                    set @sql=@sql+' where nian='+cast(@curr_year as varchar(4))+
                                            ' and gj= '''+@gj+''''
                                    print @sql
                                    exec sp_executesql  @sql
                                 end
                                 set @qwgj=substring(@qwgj,
                                            charindex(',',@qwgj)+1,
                                            len(@qwgj)-charindex(',',@qwgj))
                              set @first='N'--接下来国家不用再累加至首站国
                           end
                        end 
                  end
            end
      end
   if @err_code<>'NONE'   
      begin
         if @err_table<>''  
            begin
               select @bm=name from /*[192.168.10.2].*/[hwy2002_shgl].[dbo].d_dep where dm=@bm_code
               select @username=cxm from /*[192.168.10.2].*/[hwy2002_shgl].[dbo].rs_zyxxb where cid=@ywy_code
               --begin set @bm=@bm_code set @username=@ywy_code end
            end
         insert into shgl_outbound_log (checktime,sysname,proce,nian,yue,bm,username,th,xl,log_text) 
         values (getdate(),@sysname,@proce,@para_year,@para_month,@bm,@username,@th,@lyxl,@err_code)
      end
end
close cursor_td
DEALLOCATE cursor_td


go

