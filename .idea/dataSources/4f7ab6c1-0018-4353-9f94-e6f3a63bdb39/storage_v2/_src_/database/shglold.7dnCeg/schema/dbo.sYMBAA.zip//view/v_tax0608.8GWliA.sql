
create     view v_tax0608 as 
SELECT '1~~' + 
  shenfzh 
 + '~~010000~~1~~20060801~~20060831~~31~~'
 + CONVERT(varchar(20), jine)
 + '~~'+CONVERT(varchar(20), isnull(kouj,0))+'~~0~~0' AS Expr1
FROM saltrip_gz
where nian='06' and yue='08' and py=0

union

SELECT '1~~' + 
  shenfzh 
 + '~~040000~~1~~20060801~~20060831~~31~~'
 + CONVERT(varchar(20), jine)
 + '~~'+CONVERT(varchar(20), isnull(kouj,0))+'~~0~~0' AS Expr1
FROM saltrip_gz
where nian='06' and yue='08' and py>0


go

