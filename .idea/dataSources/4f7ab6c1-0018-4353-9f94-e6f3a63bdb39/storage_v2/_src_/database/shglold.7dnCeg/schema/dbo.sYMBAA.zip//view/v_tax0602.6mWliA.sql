






CREATE        view v_tax0602 as 
SELECT '1~~' + 

  shenfzh 

 + '~~010000~~1~~20060201~~20060228~~28~~'
 + CONVERT(varchar(20), jine)
 + '~~'+CONVERT(varchar(20), isnull(kouj,0))+'~~0~~0' AS Expr1
FROM saltrip_gz
where nian='06' and yue='02'


go

