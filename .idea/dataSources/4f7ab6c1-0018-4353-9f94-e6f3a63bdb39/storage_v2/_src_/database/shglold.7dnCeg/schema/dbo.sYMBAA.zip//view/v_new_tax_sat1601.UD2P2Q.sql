CREATE  view [dbo].[v_new_tax_sat1601] as 

SELECT * 
FROM saltrip_gz_new
where 年='16' and 月='01'
go

