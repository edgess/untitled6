
CREATE  view v_crm_email as
SELECT NAME, '<'+EMAIL+'>' mail,'member_doc' source
FROM MEMBER_DOC
WHERE       (ISNULL(EMAIL, '') <> '')
union
select NAME, '<'+EMAIL+'>' mail,'trm_member' source
from trm_member 
where isnull(member_code,'')<>'FMFFP' and ( isnull(email,'')<>'')
union
select familyname + firstname, '<' + email + '>' mail, 'web_member' source
from sh962008.dbo.web_member
WHERE (ISNULL(EMAIL, '') <> '')

go

