create view v_star as
select * from srr_demo.dbo.srr_code_item
where code_type_id='5'

go

