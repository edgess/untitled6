CREATE VIEW dbo.v_outbound_td
AS
SELECT YEAR(yqrq1) AS nian, MONTH(yqrq1) AS yue, RTRIM(th) AS th, COUNT(*) 
      AS rs
FROM hwy2002_shgl.dbo.hw_dztly hw_dztly_1
WHERE (ISNULL(th, '') <> '')
GROUP BY YEAR(yqrq1), MONTH(yqrq1), RTRIM(th)
go

