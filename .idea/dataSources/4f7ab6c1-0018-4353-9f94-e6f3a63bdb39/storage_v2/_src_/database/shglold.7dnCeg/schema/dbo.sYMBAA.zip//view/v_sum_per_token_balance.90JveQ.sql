


CREATE    view v_sum_per_token_balance as
select 
m.id,m.member_id,m.name,m.member_code,m.dept_id,
z.token_code,z.token_type,z.token_date,z.token_invalid_date,z.token_count,
isnull(u.token_used,0) token_used,
z.token_count-isnull(u.token_used,0) token_balance
--from trm_member m,v_sum_per_token u,trm_token z
--where u.token_record_id=z.record_id and z.mem_id=m.id
from 
trm_token z left join v_sum_per_token u 
on u.token_record_id=z.record_id left join trm_member m
on z.mem_id=m.id


go

