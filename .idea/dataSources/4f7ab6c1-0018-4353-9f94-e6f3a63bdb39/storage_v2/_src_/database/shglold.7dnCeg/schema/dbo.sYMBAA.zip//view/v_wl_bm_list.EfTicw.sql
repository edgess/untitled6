/*select a.dept_swm bum,b.mc laibzl,c.mc tl,d.mc xiangm  
from  v_wl_bm_list a,d_lbzl b,shgl_zilian_sanke_tl c,shgl_zilian_sanke_xiangm d
order by a.dept_swm,b.dm,c.dm,d.dm
*/
create view v_wl_bm_list as 
select distinct dept_swm,year(rjrq) nian from travelsys_new.dbo.wl_tdzl where qrbz=1

go

