create trigger ut_b2c_signup on dbo.B2C_SIGNUP
for INSERT,UPDATE
as
insert into B2C_SIGNUP_HISTORY(stringid, Signup_id, isdeal, check_operator, check_time, sales_name, dealexplain) 
select id,signup_id,isdeal,check_operator,check_time,sales_name,dealexplain from inserted
go

