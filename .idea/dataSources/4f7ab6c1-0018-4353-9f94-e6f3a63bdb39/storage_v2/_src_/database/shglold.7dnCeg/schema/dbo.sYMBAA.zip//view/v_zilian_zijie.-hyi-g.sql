/*and a.nian=2005
order by nian,bum,laibzl,tl,xiangm
*/
CREATE VIEW dbo.v_zilian_zijie
AS
SELECT a.nian, a.bum AS bumbh, b.name AS bum, a.laibzl AS lbbh, c.mc AS laibzl, 
      a.tl AS tlbh, d.mc AS tl, a.xiangm AS xmbh, e.mc AS xiangm, a.zj1 AS yue1, 
      a.zj2 AS yue2, a.zj3 AS yue3, a.zj4 AS yue4, a.zj5 AS yue5, a.zj6 AS yue6, 
      a.zj7 AS yue7, a.zj8 AS yue8, a.zj9 AS yue9, a.zj10 AS yue10, a.zj11 AS yue11, 
      a.zj12 AS yue12, 
      a.zj1 + a.zj2 + a.zj3 + a.zj4 + a.zj5 + a.zj6 + a.zj7 + a.zj8 + a.zj9 + a.zj10 + a.zj11 + a.zj12
       AS yearsum
FROM dbo.shgl_inbound a INNER JOIN
      dbo.d_dep b ON a.bum = b.dm INNER JOIN
      dbo.d_lbzl c ON a.laibzl = c.dm INNER JOIN
      dbo.shgl_inbound_tl d ON a.tl = d.dm INNER JOIN
      dbo.shgl_inbound_xiangm e ON a.xiangm = e.dm
go

