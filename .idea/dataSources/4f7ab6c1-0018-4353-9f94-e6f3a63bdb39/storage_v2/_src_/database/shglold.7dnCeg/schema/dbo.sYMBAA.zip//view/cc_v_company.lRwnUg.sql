CREATE VIEW dbo.CC_V_Company
AS
SELECT     order_id, Agent_type, agent_name, Dept_name, Depart_Simple_Name, STATUS, ISNULL(TELEPHONE, '') AS TELEPHONE, ISNULL(FAX, '') AS FAX
FROM         dbo.agent
go

