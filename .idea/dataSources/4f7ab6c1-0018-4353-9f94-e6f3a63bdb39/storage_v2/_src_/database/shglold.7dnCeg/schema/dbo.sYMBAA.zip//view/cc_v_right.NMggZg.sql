CREATE VIEW dbo.CC_V_Right
AS
SELECT     dbo.Operator_Info.id, dbo.Operator_Info.login_name, dbo.Operator_Info.name, dbo.Operator_Info.pwd, dbo.agent.Dept_name, 
                      dbo.Group_Info.name AS Group_Info_name, dbo.agent.order_id, dbo.agent.agent_name, dbo.agent.Agent_type, dbo.Operator_Info.tel, dbo.agent.ID AS agentid, 
                      dbo.Operator_Info.fax, dbo.agent.Depart_Simple_Name, dbo.Operator_Info.shengfzh, dbo.Operator_Info.email, dbo.Operator_Info.mob, dbo.Operator_Info.ext, 
                      dbo.Operator_Info.mob_ext
FROM         dbo.agent INNER JOIN
                      dbo.Group_Oper INNER JOIN
                      dbo.Group_Info ON dbo.Group_Oper.group_id = dbo.Group_Info.id INNER JOIN
                      dbo.Operator_Info ON dbo.Group_Oper.op_id = dbo.Operator_Info.id ON dbo.agent.ID = dbo.Operator_Info.agent_id
go

exec sp_addextendedproperty 'MS_Description', 'id', 'SCHEMA', 'dbo', 'VIEW', 'CC_V_Right', 'COLUMN', 'id'
go

exec sp_addextendedproperty 'MS_Description', '登录名', 'SCHEMA', 'dbo', 'VIEW', 'CC_V_Right', 'COLUMN', 'login_name'
go

exec sp_addextendedproperty 'MS_Description', '真实姓名', 'SCHEMA', 'dbo', 'VIEW', 'CC_V_Right', 'COLUMN', 'name'
go

exec sp_addextendedproperty 'MS_Description', '密码', 'SCHEMA', 'dbo', 'VIEW', 'CC_V_Right', 'COLUMN', 'pwd'
go

exec sp_addextendedproperty 'MS_Description', '电话', 'SCHEMA', 'dbo', 'VIEW', 'CC_V_Right', 'COLUMN', 'tel'
go

