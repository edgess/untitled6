





--1~~310101195011060816~~010001~~1~~20060101~~20061231~~~~20000~~0~~1975~~0





CREATE  view v_tax_sat0802_year as 
SELECT '1~~' + 
  shenfzh 
 + '~~010001~~1~~20070101~~20071231~~~~'
 + '0'
 + '~~'+'0'+'~~0~~0' AS Expr1
FROM saltrip_gz
where nian='08' and yue='02' and py=0 and left(bm,5)<>'01006'

union

SELECT '1~~' + 
  shenfzh 
 + '~~040001~~1~~20070101~~20071231~~~~'
 + '0'
 + '~~'+'0'+'~~0~~0' AS Expr1
FROM saltrip_gz
where nian='08' and yue='02' and py>0 and left(bm,5)<>'01006'


go

