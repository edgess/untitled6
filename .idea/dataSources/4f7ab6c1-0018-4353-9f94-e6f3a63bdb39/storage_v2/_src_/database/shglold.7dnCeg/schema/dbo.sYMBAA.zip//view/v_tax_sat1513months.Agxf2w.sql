







CREATE  view [dbo].[v_tax_sat1513months] as 
SELECT '1~~' +  shenfzh + '~~010001~~1~~20150101~~20151231~~~~'
 + CONVERT(varchar(20), isnull(jine,0)) + '~~0~~'+ CONVERT(varchar(20),isnull(jine,0)) + '~~'+CONVERT(varchar(20), isnull(kouj,0))
 +'~~0~~156~~0~~0~~0~~'+ CONVERT(varchar(20), isnull(nianj_qy,0)) + '~~'+ CONVERT(varchar(20),isnull(nianj_gr,0)) AS Expr1
FROM saltrip_gz
where nian='15' and yue='13' and py=0 --and left(bm,5)<>'01006'

union

SELECT '1~~' +  shenfzh + '~~010001~~1~~20150101~~20151231~~~~'
 + CONVERT(varchar(20), isnull(jine,0)) + '~~0~~'+ CONVERT(varchar(20), isnull(jine,0)) + '~~'+CONVERT(varchar(20), isnull(kouj,0))
 +'~~0~~156~~0~~0~~0~~'+ CONVERT(varchar(20), isnull(nianj_qy,0)) + '~~'+ CONVERT(varchar(20), isnull(nianj_gr,0)) AS Expr1
FROM saltrip_gz
where nian='15' and yue='13' and py>0 --and left(bm,5)<>'01006'


go

