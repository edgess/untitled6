CREATE view v_emp200909(emp) as
SELECT no+'~~'+name+'~~1~~'+id+'~~'+case sex when '男' then '1' else '0' end+'~~'+birth+'~~156~~0~~0~~~~江苏路599号~~'
+case none when '调离' then '2' else '0' end+'~~0~~200050'
FROM emp200909
go

