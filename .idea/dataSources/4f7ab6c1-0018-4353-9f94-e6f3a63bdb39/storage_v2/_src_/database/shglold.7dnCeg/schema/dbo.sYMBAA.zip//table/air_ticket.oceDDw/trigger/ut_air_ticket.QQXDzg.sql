create  trigger ut_air_ticket on dbo.air_ticket
for INSERT,UPDATE
as
insert into air_ticket_history(stringid, order_no, state, check_operator, check_time, sales_name, dealexplain) 
select id,order_no,state,check_operator,check_time,sales_name,dealexplain from inserted
go

