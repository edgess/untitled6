

CREATE   VIEW dbo.v_operator
AS
SELECT b.Dept_name, b.agent_name AS agent_names, b.Agent_type, 
      b.STATUS AS statusAgent, a.id, a.renshi_id, a.bianh, a.gongh, a.login_name, a.name, 
      a.sex, a.chusrq, a.zhengzmm, a.minz, a.shengfzh, a.hunyzk, a.addr, a.hukszd, 
      a.postcode, a.email, a.tel, a.mob, a.ext, a.mob_ext, a.fax, a.zuigxl, a.zuigxlrq, 
      a.xuelfs, a.zuigxw, a.zuigxwrq, a.biyxx, a.zhuany, a.zhic, a.zhij, a.gongzrq, a.jingsrq, 
      a.bumbh, a.chusbh, a.kesbh, a.renybh, a.agent_id, a.pwd, a.status_num, a.status, 
      a.status_date, a.isemployee, a.yanglbxbh, a.date_created, a.disabled, a.remark, 
      a.op_id, a.op_date, a.agent_name, a.xgx_id, a.xgx_dept_id, a.jzl_id, a.jzl_dept_id, 
      a.is_sales, a.rjy_id, a.rjy_dept_id, a.station_name, a.superior_id, a.leader_id, 
      a.home_tel, a.home_fax, a.py, a.chusd, a.passport, a.passport_date, 
      a.passport_address, a.passport_available_date, a.leader_number, 
      a.HongKongMaCaoPass, a.HongKongMaCaoPlace, a.HongKongMaCaoDate, 
      a.HongKongMaCaoAvailableDate,a.TaiWanPass,a.TaiWanPlace,
      a.TaiWanDate,a.TaiWanAvailableDate
FROM dbo.Operator_Info a INNER JOIN
      dbo.agent b ON a.agent_id = b.ID AND b.STATUS = 'Y'


go

