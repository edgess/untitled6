
CREATE  PROCEDURE spPage
  @tb              varchar(50),          --表名
  @col             varchar(50),          --按该列来进行分页
  @collist         nvarchar(4000),    	 --要查询出的字段列表,*表示全部字段
  @collist1         nvarchar(4000),      --附加
  @condition       nvarchar(4000),       --查询条件
  @orderby         varchar(4000),         --当页排序
  @pagesize        int,                  --每页记录数
  @page            int,                  --指定页
  @records         int OUTPUT,           --总记录数
  @recordcount   int OUTPUT              --返回记录数
AS
DECLARE @sql nvarchar(4000),@sql1 nvarchar(4000),@sql2 nvarchar(4000),@sql3 nvarchar(4000),@where nvarchar(4000),@where1 nvarchar(4000),@orderby1 varchar(4000)
IF @condition is null or rtrim(@condition)=''
   BEGIN--没有查询条件
      SET @where=''
      SET @where1=''
   END
ELSE
   BEGIN--有查询条件
      SET @where='WHERE ('+@condition+')'
      SET @where1='AND ('+@condition+')'
END


IF @orderby is null or rtrim(@orderby)=''
   BEGIN--没有排序条件
      SET @orderby1='order by '+@col
   END
ELSE
   BEGIN--有排序条件
      SET @orderby1='order by '+@orderby
END

SET @sql='SELECT @records=COUNT(*) FROM '+@tb+' '+@where
EXEC sp_executesql @sql,N'@records int OUTPUT',@records OUTPUT--计算总记录数


SET @sql1= ' WHERE( '+@col+' NOT IN (SELECT TOP '+CAST((@pagesize*(@page-1)) AS varchar)+' '+@col+' FROM '+@tb+' '
SET @sql2= @where+' '+@orderby1+'))  '
SET @sql3= @where1+' '+@orderby1

--SET @sql1=' WHERE( '+@col+' NOT IN (SELECT TOP '+CAST((@pagesize*(@page-1)) AS varchar)+' '+@col+' FROM '+@tb+' '+ @where+' '+@orderby1+'))  '+@where1+' '+@orderby1
--EXEC  ('SELECT TOP '+@pagesize+' '+@collist+@collist1+' from ' + @tb + @sql1)

EXEC  ('SELECT TOP '+@pagesize+' '+@collist+@collist1+' from ' + @tb + @sql1+@sql2+@sql3)


SET @recordcount = @@rowcount
go

