
CREATE  VIEW dbo.v_gl_route
AS
SELECT a.id AS id, a.line_name AS line_name, a.line_code AS line_code, 
      a.date_end AS date_end, b.[day] AS [day], b.items AS items, b.area AS area, 
      b.id AS days_id, left(a.line_code, 3) as page, case when len(a.line_code) > 3 then substring(a.line_code, 4, len(a.line_code) - 3) else '' end as page_order
FROM inlandtravel.dbo.line_info a INNER JOIN
      inlandtravel.dbo.days_info b ON a.id = b.line_id
WHERE (a.date_end > GETDATE()) AND (a.is_templet = 0) AND (a.is_publish = 1) AND 
      (a.is_publish_b2b = 1)

go

