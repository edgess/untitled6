










CREATE           procedure usp_cj_ctms (@para_year varchar(4),@para_month varchar(2) )
AS 
declare @qcts int/*天数*/
declare @th varchar(80)/*团号*/
declare @tdrs int/*团队人数*/
declare @qwgj varchar(400)/*前往国家*/
declare @curr_year int
declare @curr_month int
declare @sql nvarchar(1000)
declare @cond varchar(1000)
declare @foundrows int
declare @cut_point int
declare @gj varchar(50)
declare @first char(1)--首站国标志

declare cursor_td cursor for
select a.team_code, a.now_population, b.goal_country, b.travel_day
  from shgl_ctms.dbo.ctms_sale_plan a, shgl_ctms.dbo.ctms_product b
  where a.product_id = b.product_id
    and left(convert(varchar(10), convert(datetime, a.embarks_date, 120), 120), 4) = @para_year
    and substring(convert(varchar(10), convert(datetime, a.embarks_date, 120), 120), 6, 2) = @para_month
    and a.team_state <> '删除'
    and a.now_population <> 0

set @curr_year=@para_year
set @curr_month=@para_month

set @sql = N'update shgl_outbound set '+
           'td'+cast(@curr_month as varchar(2))+' = 0,'+
           'sz'+cast(@curr_month as varchar(2))+' = 0,'+
           'rts'+cast(@curr_month as varchar(2))+' = 0,'+
           'qw'+cast(@curr_month as varchar(2))+' = 0 where nian='+cast(@curr_year as varchar(4))
exec sp_executesql  @sql

open cursor_td
WHILE 1=1
BEGIN
   fetch next from cursor_td into @th,@tdrs,@qwgj,@qcts
   if @@FETCH_STATUS <> 0 break
   set @qwgj=@qwgj+',' set @qwgj=replace(@qwgj,'、',',') set @qwgj=replace(@qwgj,'，',',') set @qwgj=replace(@qwgj,'。',',') set @qwgj=replace(@qwgj,'‘',',') set @qwgj=replace(@qwgj,'／',',') set @qwgj=replace(@qwgj,'＼',',') set @qwgj=replace(@qwgj,'＇',',') set @qwgj=replace(@qwgj,'；',',') set @qwgj=replace(@qwgj,'　',',') set @qwgj=replace(@qwgj,' ',',') set @qwgj=replace(@qwgj,'\',',') set @qwgj=replace(@qwgj,'/',',') set @qwgj=replace(@qwgj,'.',',') set @qwgj=replace(@qwgj,';',',')
   set @cut_point=1
   set @first='Y'
   while @cut_point<len(@qwgj)
   begin
     set @gj=substring(@qwgj,1,charindex(',',@qwgj)-1)
     select @foundrows=count(*) from shgl_outbound where gj=@gj and nian=@curr_year
     if @foundrows=0 insert into shgl_outbound (nian,gj) values (@curr_year,@gj)
     set @sql = 'update shgl_outbound set qw'+
       cast(@curr_month as varchar(2))+' = qw'+
       cast(@curr_month as varchar(2))+'+'+cast(@tdrs as char)
     if @first='Y'
     begin
       set @sql =@sql+ ',sz'+cast(@curr_month as varchar(2))+
         ' = sz'+cast(@curr_month as varchar(2))+ 
         '+'+cast(@tdrs as char)
       set @sql =@sql+',rts'+cast(@curr_month as varchar(2))+
         ' = rts'+cast(@curr_month as varchar(2))+ 
         '+'+cast(@tdrs*@qcts as char)
       set @sql =@sql+',td'+cast(@curr_month as varchar(2))+
         ' = td'+cast(@curr_month as varchar(2))+ 
         '+1'
      end
      set @sql=@sql+' where nian='+cast(@curr_year as varchar(4))+
        ' and gj= '''+@gj+''''
      print @sql
      exec sp_executesql  @sql
      set @qwgj=substring(@qwgj, charindex(',',@qwgj)+1, len(@qwgj)-charindex(',',@qwgj))
      set @first='N'--接下来国家不用再累加至首站国
   end
end

close cursor_td
DEALLOCATE cursor_td


go

