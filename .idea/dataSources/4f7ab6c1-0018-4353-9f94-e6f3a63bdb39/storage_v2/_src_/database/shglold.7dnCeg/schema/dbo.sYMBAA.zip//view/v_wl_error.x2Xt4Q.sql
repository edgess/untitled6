create   view v_wl_error as 
select b.th,a.qrth,a.xh,a.cfcsdm,a.csdm,a.ddbc,a.lksj,a.ddsj,a.gys,a.lkrqdw,a.shlx,a.nid,a.zh,a.crs 
from travelsys_new.dbo.wl_tdmx a,shgl_inbound_log b
where a.qrth=b.tdid
go

