






CREATE         procedure usp_wl (@para_year varchar(4),@para_month varchar(2) )
AS 

declare @curr_year int
declare @curr_month int
declare @count_line int
declare @bum char(4)
declare @laibzl varchar(50)
declare @tl varchar(50)
declare @pc int
declare @rs int
declare @rts int

--select @curr_year=year(dateadd(mm,1,getdate())),@curr_month=month(dateadd(mm,1,getdate()))
set @curr_year=@para_year
set @curr_month=@para_month

--判断是否开始统计
--if day(getdate())<=10 return

--保证表格的行数正确
insert into shgl_inbound (nian,bum,laibzl,tl,xiangm )
select a.nian,a.dept_swm bum,b.dm laibzl,c.dm tl,d.dm xiangm  
from  v_wl_bm_list a,travelsys_new.dbo.d_lbzl b,shgl_inbound_tl c,shgl_inbound_xiangm d
where (select count(*) from shgl_inbound t 
	where a.nian=t.nian and a.dept_swm=t.bum and b.dm=t.laibzl and c.dm=t.tl and d.dm=t.xiangm)=0

/*以下是自联团队和散客的统计*/
--分部门，分来宾的过夜游团队统计
declare cursor_duoriyou cursor for
select a.dept_swm/*部门*/,a.snwbz/*来宾*/,'1'/*过夜游团标志*/,count(*)/*批次*/,
sum(isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))/*人数*/,
sum((isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))*a.qcts)/*人天数*/
from travelsys_new.dbo.wl_tdzl a
where year(a.rjrq)=@curr_year and month(a.rjrq)=@curr_month and a.qrbz=1 and a.tl<>3  and a.qcts>1
group by a.dept_swm,a.snwbz

--分部门，分来宾的一日游团队统计
declare cursor_yiriyou cursor for
select a.dept_swm/*部门*/,a.snwbz/*来宾*/,'2'/*一日游团标志*/,count(*)/*批次*/,
sum(isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))/*人数*/,
sum((isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))*a.qcts)/*人天数*/
from travelsys_new.dbo.wl_tdzl a
where year(a.rjrq)=@curr_year and month(a.rjrq)=@curr_month and a.qrbz=1 and a.tl<>3 and a.qcts=1
group by a.dept_swm,a.snwbz

--分部门，分来宾的散客统计
declare cursor_sanke cursor for
select a.dept_swm/*部门*/,a.snwbz/*来宾*/,'3'/*散客标志*/,count(*)/*批次*/,
sum(isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))/*人数*/,
sum((isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))*a.qcts)/*人天数*/
from travelsys_new.dbo.wl_tdzl a
where year(a.rjrq)=@curr_year and month(a.rjrq)=@curr_month and a.qrbz=1 and a.tl=3
group by a.dept_swm,a.snwbz

declare @sql1 nvarchar(1000)
declare @sql2 nvarchar(1000)
declare @sql3 nvarchar(1000)
--初始化该年该月的自联散客数据
set @sql1 = 'update shgl_inbound set wl'+cast(@curr_month as varchar(2))+' = 0 where nian='+cast(@curr_year as varchar(4))
exec sp_executesql  @sql1

--处理过夜游团队数据
open cursor_duoriyou
fetch next from cursor_duoriyou into @bum,@laibzl,@tl,@pc,@rs,@rts
WHILE @@FETCH_STATUS = 0
BEGIN
   set @sql1 = 'update shgl_inbound set wl'+cast(@curr_month as varchar(2))+' = '+cast(@pc as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''1'' and xiangm=''1'''
   set @sql2 = 'update shgl_inbound set wl'+cast(@curr_month as varchar(2))+' = '+cast(@rs as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''1'' and xiangm=''2'''
   set @sql3 = 'update shgl_inbound set wl'+cast(@curr_month as varchar(2))+' = '+cast(@rts as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''1'' and xiangm=''3'''
   exec sp_executesql  @sql1
   exec sp_executesql  @sql2
   exec sp_executesql  @sql3
   fetch next from cursor_duoriyou into @bum,@laibzl,@tl,@pc,@rs,@rts
end
close cursor_duoriyou
DEALLOCATE cursor_duoriyou

--处理一日游团队数据
open cursor_yiriyou
fetch next from cursor_yiriyou into @bum,@laibzl,@tl,@pc,@rs,@rts
WHILE @@FETCH_STATUS = 0
BEGIN
   set @sql1 = 'update shgl_inbound set wl'+cast(@curr_month as varchar(2))+' = '+cast(@pc as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''2'' and xiangm=''1'''
   set @sql2 = 'update shgl_inbound set wl'+cast(@curr_month as varchar(2))+' = '+cast(@rs as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''2'' and xiangm=''2'''
   set @sql3 = 'update shgl_inbound set wl'+cast(@curr_month as varchar(2))+' = '+cast(@rts as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''2'' and xiangm=''3'''
   exec sp_executesql  @sql1
   exec sp_executesql  @sql2
   exec sp_executesql  @sql3
   fetch next from cursor_yiriyou into @bum,@laibzl,@tl,@pc,@rs,@rts
end
close cursor_yiriyou
DEALLOCATE cursor_yiriyou

--处理散客数据
open cursor_sanke
fetch next from cursor_sanke into @bum,@laibzl,@tl,@pc,@rs,@rts
WHILE @@FETCH_STATUS = 0
BEGIN
   set @sql1 = 'update shgl_inbound set wl'+cast(@curr_month as varchar(2))+' = '+cast(@pc as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''3'' and xiangm=''1'''
   set @sql2 = 'update shgl_inbound set wl'+cast(@curr_month as varchar(2))+' = '+cast(@rs as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''3'' and xiangm=''2'''
   set @sql3 = 'update shgl_inbound set wl'+cast(@curr_month as varchar(2))+' = '+cast(@rts as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''3'' and xiangm=''3'''
   exec sp_executesql  @sql1
   exec sp_executesql  @sql2
   exec sp_executesql  @sql3
   fetch next from cursor_sanke into @bum,@laibzl,@tl,@pc,@rs,@rts
end
close cursor_sanke
DEALLOCATE cursor_sanke



/*以下是自联自接团队和散客的统计*/
--v_wl_sh.tdid  v_wl_sh.shts
--分部门，分来宾的过夜游团队统计
declare cursor_duoriyou cursor for
select a.dept_swm/*部门*/,a.snwbz/*来宾*/,'1'/*过夜游团标志*/,count(*)/*批次*/,
sum(isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))/*人数*/,
sum((isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))*a.qcts)/*人天数*/
from travelsys_new.dbo.wl_tdzl a,v_wl_sh b
where year(a.rjrq)=@curr_year and month(a.rjrq)=@curr_month and a.qrbz=1 and a.tl<>3  and a.qcts>1
      and a.tdid=b.tdid
group by a.dept_swm,a.snwbz

--分部门，分来宾的一日游团队统计
declare cursor_yiriyou cursor for
select a.dept_swm/*部门*/,a.snwbz/*来宾*/,'2'/*一日游团标志*/,count(*)/*批次*/,
sum(isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))/*人数*/,
sum((isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))*a.qcts)/*人天数*/
from travelsys_new.dbo.wl_tdzl a,v_wl_sh b
where year(a.rjrq)=@curr_year and month(a.rjrq)=@curr_month and a.qrbz=1 and a.tl<>3 and a.qcts=1
      and a.tdid=b.tdid
group by a.dept_swm,a.snwbz

--分部门，分来宾的散客统计
declare cursor_sanke cursor for
select a.dept_swm/*部门*/,a.snwbz/*来宾*/,'3'/*散客标志*/,count(*)/*批次*/,
sum(isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))/*人数*/,
sum((isnull(a.cr,0)+isnull(a.rt,0)+isnull(a.yr,0))*a.qcts)/*人天数*/
from travelsys_new.dbo.wl_tdzl a,v_wl_sh b
where year(a.rjrq)=@curr_year and month(a.rjrq)=@curr_month and a.qrbz=1 and a.tl=3
      and a.tdid=b.tdid
group by a.dept_swm,a.snwbz

--初始化该年该月的自联自接数据
set @sql1 = 'update shgl_inbound set zj'+cast(@curr_month as varchar(2))+' = 0 where nian='+cast(@curr_year as varchar(4))
exec sp_executesql  @sql1

--处理过夜游团队数据
open cursor_duoriyou
fetch next from cursor_duoriyou into @bum,@laibzl,@tl,@pc,@rs,@rts
WHILE @@FETCH_STATUS = 0
BEGIN
   set @sql1 = 'update shgl_inbound set zj'+cast(@curr_month as varchar(2))+' = '+cast(@pc as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''1'' and xiangm=''1'''
   set @sql2 = 'update shgl_inbound set zj'+cast(@curr_month as varchar(2))+' = '+cast(@rs as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''1'' and xiangm=''2'''
   set @sql3 = 'update shgl_inbound set zj'+cast(@curr_month as varchar(2))+' = '+cast(@rts as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''1'' and xiangm=''3'''
   exec sp_executesql  @sql1
   exec sp_executesql  @sql2
   exec sp_executesql  @sql3
   fetch next from cursor_duoriyou into @bum,@laibzl,@tl,@pc,@rs,@rts
end
close cursor_duoriyou
DEALLOCATE cursor_duoriyou

--处理一日游团队数据
open cursor_yiriyou
fetch next from cursor_yiriyou into @bum,@laibzl,@tl,@pc,@rs,@rts
WHILE @@FETCH_STATUS = 0
BEGIN
   set @sql1 = 'update shgl_inbound set zj'+cast(@curr_month as varchar(2))+' = '+cast(@pc as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''2'' and xiangm=''1'''
   set @sql2 = 'update shgl_inbound set zj'+cast(@curr_month as varchar(2))+' = '+cast(@rs as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''2'' and xiangm=''2'''
   set @sql3 = 'update shgl_inbound set zj'+cast(@curr_month as varchar(2))+' = '+cast(@rts as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''2'' and xiangm=''3'''
   exec sp_executesql  @sql1
   exec sp_executesql  @sql2
   exec sp_executesql  @sql3
   fetch next from cursor_yiriyou into @bum,@laibzl,@tl,@pc,@rs,@rts
end
close cursor_yiriyou
DEALLOCATE cursor_yiriyou

--处理散客数据
open cursor_sanke
fetch next from cursor_sanke into @bum,@laibzl,@tl,@pc,@rs,@rts
WHILE @@FETCH_STATUS = 0
BEGIN
   set @sql1 = 'update shgl_inbound set zj'+cast(@curr_month as varchar(2))+' = '+cast(@pc as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''3'' and xiangm=''1'''
   set @sql2 = 'update shgl_inbound set zj'+cast(@curr_month as varchar(2))+' = '+cast(@rs as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''3'' and xiangm=''2'''
   set @sql3 = 'update shgl_inbound set zj'+cast(@curr_month as varchar(2))+' = '+cast(@rts as char)+' 
                where nian='+cast(@curr_year as varchar(4))+' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''3'' and xiangm=''3'''
   exec sp_executesql  @sql1
   exec sp_executesql  @sql2
   exec sp_executesql  @sql3
   fetch next from cursor_sanke into @bum,@laibzl,@tl,@pc,@rs,@rts
end
close cursor_sanke
DEALLOCATE cursor_sanke


go

