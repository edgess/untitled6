CREATE VIEW dbo.hr_t_bum
AS
SELECT   ID, SUBSTRING(order_id, 1, 2) AS bumbh, agent_name AS bum
FROM      dbo.hr_agent
WHERE   (Agent_type IN ('公司部门', '直销网点')) AND (STATUS = 'Y') AND (LEN(order_id) = 2)
go

