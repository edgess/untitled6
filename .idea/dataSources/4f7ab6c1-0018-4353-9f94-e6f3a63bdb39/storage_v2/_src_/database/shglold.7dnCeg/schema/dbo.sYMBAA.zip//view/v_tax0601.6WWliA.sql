



CREATE     view v_tax0601 as 
SELECT '1~~' + 

  shenfzh 

 + '~~010000~~1~~20060101~~20060131~~31~~'
 + CONVERT(varchar(10), jine)
 + '~~1600~~0~~0' AS Expr1
FROM saltrip_gz
where nian='06' and yue='01'


go

