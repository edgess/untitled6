/*and 
a.agent_type in ('公司部门','直销网点') and substring(a.order_id,1,1)<>'T'  
b.isemployee='Y'
*/
CREATE VIEW dbo.saltrip_human
AS
SELECT     a.Agent_type, a.order_id, a.agent_name, b.id, b.login_name, b.name, b.agent_id, b.pwd, b.station_name, b.renshi_id, b.bianh, b.gongh, b.sex, b.chusrq, b.hunyzk, 
                      b.shengfzh, b.minz, b.zhengzmm, b.addr, b.hukszd, b.tel, b.ext, b.home_tel, b.home_fax, b.home_fax AS fax, b.postcode, b.mob, b.mob_ext, b.zuigxl, b.zuigxw, 
                      b.biyxx, b.zhuany, b.zhic, b.gongzrq, b.jingsrq, SUBSTRING(a.order_id, 1, 2) AS bumbh, SUBSTRING(a.order_id, 3, 2) AS chusbh, SUBSTRING(a.order_id, 5, 2) 
                      AS kesbh, b.renybh, b.zhij, b.status, b.status_date, b.yanglbxbh, b.zuigxlrq, b.zuigxwrq, b.xuelfs, b.isemployee, b.email, b.superior_id, b.leader_id
FROM         dbo.agent AS a INNER JOIN
                      dbo.Operator_Info AS b ON a.ID = b.agent_id
WHERE     (b.status IS NOT NULL)
go

