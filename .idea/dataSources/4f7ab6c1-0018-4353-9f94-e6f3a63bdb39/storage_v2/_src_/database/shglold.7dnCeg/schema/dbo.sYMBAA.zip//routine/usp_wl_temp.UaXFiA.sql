








CREATE                  procedure usp_wl_temp (@para_year varchar(4),@para_month varchar(2) )
AS 
declare @curr_year int
declare @curr_month int
declare @err_code varchar(1000)
declare @sysname varchar(50) set @sysname='入境游外联系统'
declare @proce varchar(20) set @proce='自联自接单月统计'

delete from shgl_inbound_log where nian=@para_year and yue=@para_month and sysname=@sysname and proce=@proce

set @curr_year=@para_year
set @curr_month=@para_month

declare @count_line int
--对应wl_tdzl的变量说明
declare @tdh varchar(40)/*团队id*/
declare @tdhm varchar(40)/*团队号*/
declare @bum char(4)/*部门代码*/
declare @laibzl varchar(50)/*来宾种类代码*/
declare @tl varchar(50)/*团类代码1-自组，2-横向，3-散客*/
declare @tdrs int/*团队人数*/
declare @username varchar(10)/*输入人*/

--对应wl_tdmx的变量说明
declare @xh int/*第几天*/
declare @cfcs varchar(24)/*出发城市代码*/
declare @ddcs varchar(24)/*抵达城市代码*/
declare @shcs int/*一个团进上海的次数*/
declare @shts int/*一个团进上海的天数*/
declare @sh char(1)/*一个团当天在上海的标志*/
declare @oneday char(1)/*一日游的标志*/
declare @lastcity varchar(24)/*一个团昨天所在城市*/
declare @lastxh int/*一个团昨天行程序号*/

--最后统计值
declare @pc int/*批次*/
declare @rs int/*人数*/
declare @rts int/*人天数*/

declare cursor_tdzl cursor for
select rtrim(tdid),rtrim(dept_swm)/*部门*/,rtrim(snwbz)/*来宾*/,tl/*团类*/,
isnull(cr,0)+isnull(rt,0)+isnull(yr,0) rs/*人数*/,th,name username
from travelsys_new.dbo.wl_tdzl 
where year(rjrq)=@curr_year and month(rjrq)=@curr_month and qrbz=1  
order by qrth

declare @sql nvarchar(1000)
declare @cond varchar(1000)

set @sql = N'update shgl_inbound set zj'+
           cast(@curr_month as varchar(2))+
           ' = 0 where nian='+cast(@curr_year as varchar(4))
exec sp_executesql  @sql


--循环处理wl_tdzl数据
open cursor_tdzl
WHILE 1=1
BEGIN
   fetch next from cursor_tdzl into @tdh,@bum,@laibzl,@tl,@tdrs,@tdhm,@username
   if @@FETCH_STATUS <> 0 break
   if @tl=3/*散客统计*/
      begin
                     /*批次*/
                     set @sql = 'update shgl_inbound set zj'+
                                cast(@curr_month as varchar(2))+' = zj'+
                                cast(@curr_month as varchar(2))+ 
                                '+1 where nian='+cast(@curr_year as varchar(4))+
                                ' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''3'' and xiangm=''1'''
                     exec sp_executesql  @sql
                     /*人数*/
                     set @sql = 'update shgl_inbound set zj'+
                                cast(@curr_month as varchar(2))+' = zj'+
                                cast(@curr_month as varchar(2))+'+'+
                                cast(@tdrs as char)+
                                'where nian='+cast(@curr_year as varchar(4))+
                                ' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''3'' and xiangm=''2'''
                     exec sp_executesql  @sql
      end
   else    /*团队统计*/
      begin
         set @err_code='NONE'         set @shcs=0         set @shts=0         set @lastcity='NONE'
         set @lastxh=0         set @sh='N'         set @oneday='N'
         declare cursor_tdmx cursor for
         select xh,rtrim(isnull(cfcsdm,'')),rtrim(isnull(csdm,''))
         from travelsys_new.dbo.wl_tdmx 
         where qrth=@tdh order by xh,zh,shlx
         open cursor_tdmx
         WHILE 1=1 
         BEGIN
            --累加该团进上海的次数和逗留上海的天数
            fetch next from cursor_tdmx into @xh,@cfcs,@ddcs
   --print 'xh:'+cast(@xh as varchar(1))+'lastxh:'+cast(@lastxh as varchar(1))+
   --   ' lastcity:'+@lastcity+' cfcs:'+@cfcs+' ddcs:'+@ddcs+
   --   ' oneday:'+@oneday+' shcs:'+cast(@shcs as varchar(2))+
   --   ' shts:'+cast(@shts as varchar(2))

            if @@FETCH_STATUS <> 0  break
            if @cfcs='supervisor' set @cfcs=''
            if @ddcs='supervisor' set @ddcs=''
            if @lastxh=0 
               begin 
                 if @cfcs='' or @ddcs=''
                    begin set @err_code='第1天行程的城市不明确' break end
                 set @lastcity=@ddcs
                 set @lastxh=@xh
               end
            else
               begin
                  if @cfcs='' set @cfcs=@lastcity
                  if @ddcs='' set @ddcs=@cfcs 
                  if @lastxh=@xh 
                     begin
                        if @lastcity<>@cfcs 
                           begin set @err_code='第'+rtrim(cast(@lastxh as varchar(3)))+'天里的多城市安排不连贯' break end
                        if @cfcs='sh' set @oneday='Y'
                     end
                  else
                     begin 
                        if @lastcity<>@cfcs 
                           begin set @err_code='第'+rtrim(cast(@lastxh as varchar(3)))+'天到达城市'''+@lastcity+'''和第'+rtrim(cast(@xh as varchar(3)))+'天出发城市'''+@cfcs+'''不连贯' break end
                        if @cfcs='sh' 
                           begin
                              set @shts=@shts+1
                              if @ddcs<>'sh' set @shcs=@shcs+1
                           end
                     end
                  set @lastcity=@ddcs
                  set @lastxh=@xh
               end
         end
         close cursor_tdmx
         DEALLOCATE cursor_tdmx
         --累加该团数据至该部门
 
         if @shcs>@shts 
            set @err_code='上海过夜次数('+rtrim(cast(@shcs as varchar(3)))+') 超过 上海过夜夜数('+rtrim(cast(@shts as varchar(3)))+')' 
         if @err_code<>'NONE'
            begin
               insert into shgl_inbound_log (checktime,sysname,proce,nian,yue,bm,username,th,tdid,log_text) 
               values (getdate(),@sysname,@proce,@para_year,@para_month,@bum,@username,@tdhm,@tdh,@err_code)
            end
         else
            begin
               if @shcs>0 /*过夜游*/
                  begin
                     /*批次*/
                     set @sql = 'update shgl_inbound set zj'+
                                cast(@curr_month as varchar(2))+' = zj'+
                                cast(@curr_month as varchar(2))+ 
                                '+1 where nian='+cast(@curr_year as varchar(4))+
                                ' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''1'' and xiangm=''1'''
                     exec sp_executesql  @sql
                     /*人数*/
                     set @sql = 'update shgl_inbound set zj'+
                                cast(@curr_month as varchar(2))+' = zj'+
                                cast(@curr_month as varchar(2))+'+'+
                                cast(@shcs as char)+'*'+cast(@tdrs as char)+
                                'where nian='+cast(@curr_year as varchar(4))+
                                ' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''1'' and xiangm=''2'''
                     exec sp_executesql  @sql
                     /*人天数*/
                     set @sql = 'update shgl_inbound set zj'+
                                cast(@curr_month as varchar(2))+' = zj'+
                                cast(@curr_month as varchar(2))+'+'+
                                cast(@shts as char)+'*'+cast(@tdrs as char)+
                                'where nian='+cast(@curr_year as varchar(4))+
                                ' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''1'' and xiangm=''3'''
                     exec sp_executesql  @sql
                  end
               else
                  begin
                     if @oneday='Y'/*一日游*/
                        begin
                           /*批次*/
                           set @sql = 'update shgl_inbound set zj'+
                                cast(@curr_month as varchar(2))+' = zj'+
                                cast(@curr_month as varchar(2))+ 
                                '+1 where nian='+cast(@curr_year as varchar(4))+
                                ' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''2'' and xiangm=''1'''
                           exec sp_executesql  @sql
                           /*人数*/
                           set @sql = 'update shgl_inbound set zj'+
                                cast(@curr_month as varchar(2))+' = zj'+
                                cast(@curr_month as varchar(2))+'+'+
                                cast(@tdrs as char)+
                                'where nian='+cast(@curr_year as varchar(4))+
                                ' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''2'' and xiangm=''2'''
                           exec sp_executesql  @sql
                           /*人天数*/
                           set @sql = 'update shgl_inbound set zj'+
                                cast(@curr_month as varchar(2))+' = zj'+
                                cast(@curr_month as varchar(2))+'+'+
                                cast(@tdrs as char)+
                                'where nian='+cast(@curr_year as varchar(4))+
                                ' and bum= '''+@bum+''' and laibzl='+@laibzl+' and tl=''2'' and xiangm=''3'''
                           exec sp_executesql  @sql
                        end
                  end

            end
      end   
end
close cursor_tdzl

DEALLOCATE cursor_tdzl


go

