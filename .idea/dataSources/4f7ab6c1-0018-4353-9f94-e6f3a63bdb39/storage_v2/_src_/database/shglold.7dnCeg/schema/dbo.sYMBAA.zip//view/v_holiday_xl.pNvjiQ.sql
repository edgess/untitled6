CREATE VIEW dbo.v_holiday_xl
AS
SELECT a.*, b.shgl_id, c.order_id AS agent_order_id, c.agent_name AS agent_name
FROM hwy2002_shgl.dbo.hw_xl a INNER JOIN
      hwy2002_shgl.dbo.d_dep b ON a.bm = b.dm INNER JOIN
      dbo.agent c ON b.shgl_id = c.ID AND a.DM IN
          (SELECT xl
         FROM hwy2002_shgl.dbo.hw_td a, hwy2002_shgl.dbo.hw_tdxc b
         WHERE a.cfrq >= '2007-09-28' AND a.cfrq <= '2007-10-05' AND a.th = b.th)
go

