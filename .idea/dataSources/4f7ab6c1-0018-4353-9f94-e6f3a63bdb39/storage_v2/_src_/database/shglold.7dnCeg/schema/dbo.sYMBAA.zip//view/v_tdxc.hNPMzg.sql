

CREATE     view v_tdxc as
select *
from hwy2002_shgl.dbo.hw_tdxc


go

