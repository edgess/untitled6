
create view [dbo].[cc_v_menu] as
select distinct a.op_id, c.*, d.MenuName as name
from Group_Oper a, menu_group b, PermissionsMenu c, PermissionsMenu d
where a.group_id = b.group_id
and b.menu_id = c.ID
and c.ParentID = d.ID
go

